import { Component } from '@angular/core';

@Component({
  selector: 'app-device-find',
  templateUrl: './device-find.component.html',
  styleUrls: ['./device-find.component.css']
})
export class DeviceFindComponent {

}
