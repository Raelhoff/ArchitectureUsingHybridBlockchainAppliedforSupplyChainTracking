import { Device } from './device';

describe('Devices', () => {
  it('should create an instance', () => {
    expect(new Device()).toBeTruthy();
  });
});
